function graph(x, y)
  subplot(1,2,1);
  thermalplot(x);
  subplot(1,2,2);
  thermalplot(y);
end